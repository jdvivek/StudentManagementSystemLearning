﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentManagment.API.ViewModels.Students
{
    public class SelectStudentViewModel
    {

            public int Id { get; set; }
            public string Name { get; set; }
            public string EmailId { get; set; }
          
       
    }
}