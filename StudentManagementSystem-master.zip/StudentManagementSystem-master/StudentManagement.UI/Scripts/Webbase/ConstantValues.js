﻿var ConstantValues = {
    APIPath: "https://localhost:44352",





};

